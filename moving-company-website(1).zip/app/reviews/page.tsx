import { Header } from "@/components/header"
import { ReviewsPage } from "@/components/reviews-page"
import { Footer } from "@/components/footer"

export default function Reviews() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <ReviewsPage />
      </main>
      <Footer />
    </div>
  )
}
