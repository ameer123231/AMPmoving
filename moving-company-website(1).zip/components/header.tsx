"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"
import { QuoteModal } from "@/components/quote-modal"
import Link from "next/link"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState(false)

  const handleMobileNavClick = () => {
    setIsMenuOpen(false)
    // Scroll to top when navigating on mobile
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <header className="bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 shadow-lg border-b border-gray-700 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center">
            <Link href="/" className="text-white font-bold text-xl hover:text-orange-400 transition-colors">
              AMP Moving Inc
            </Link>
          </div>

          <nav className="hidden md:flex space-x-8">
            <Link href="/" className="text-white hover:text-orange-400 transition-colors font-medium text-lg">
              Home
            </Link>
            <Link href="/reviews" className="text-white hover:text-orange-400 transition-colors font-medium text-lg">
              Reviews
            </Link>
            <Link href="/contact" className="text-white hover:text-orange-400 transition-colors font-medium text-lg">
              Contact
            </Link>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <Button
              variant="outline"
              className="border-orange-500 text-orange-400 hover:bg-orange-500 hover:text-white transition-all duration-300 font-semibold"
            >
              Call Now (343) 204-6643
            </Button>
            <Button
              className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
              onClick={() => setIsQuoteModalOpen(true)}
            >
              Get Quote
            </Button>
          </div>

          <button
            className="md:hidden text-white hover:text-orange-400 transition-colors"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-6 border-t border-gray-700">
            <nav className="flex flex-col space-y-4">
              <Link
                href="/"
                className="text-white hover:text-orange-400 transition-colors font-medium text-lg"
                onClick={handleMobileNavClick}
              >
                Home
              </Link>
              <Link
                href="/reviews"
                className="text-white hover:text-orange-400 transition-colors font-medium text-lg"
                onClick={handleMobileNavClick}
              >
                Reviews
              </Link>
              <Link
                href="/contact"
                className="text-white hover:text-orange-400 transition-colors font-medium text-lg"
                onClick={handleMobileNavClick}
              >
                Contact
              </Link>
              <div className="flex flex-col space-y-3 pt-4">
                <Button
                  variant="outline"
                  className="w-full border-orange-500 text-orange-400 hover:bg-orange-500 hover:text-white transition-all duration-300 font-semibold"
                >
                  Call Now (343) 204-6643
                </Button>
                <Button
                  className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
                  onClick={() => setIsQuoteModalOpen(true)}
                >
                  Get Quote
                </Button>
              </div>
            </nav>
          </div>
        )}
        <QuoteModal isOpen={isQuoteModalOpen} onClose={() => setIsQuoteModalOpen(false)} />
      </div>
    </header>
  )
}
