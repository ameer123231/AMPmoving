import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Home, Building, Package, PenToolIcon as Tool } from "lucide-react"

export function Services() {
  const services = [
    {
      icon: Home,
      title: "Residential Moving",
      description: "Complete household moving services for families and individuals relocating across borders.",
    },
    {
      icon: Building,
      title: "Commercial Moving",
      description: "Office and business relocations with minimal downtime and professional handling.",
    },
    {
      icon: Package,
      title: "Packing Services",
      description: "Professional packing and unpacking services to ensure your items arrive safely.",
    },
    {
      icon: Tool,
      title: "Specialty Services",
      description: "Custom crating, TV installation/removal, assembly/disassembly, and fine art handling.",
    },
  ]

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Moving Services</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive moving solutions tailored to your needs, whether you're moving across the street or across the
            border.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="mx-auto w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mb-4">
                  <service.icon className="h-8 w-8 text-orange-600" />
                </div>
                <CardTitle className="text-xl">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600">{service.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
