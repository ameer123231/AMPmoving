import { Badge } from "@/components/ui/badge"
import { MapPin, Truck, CheckCircle } from "lucide-react"

export function Coverage() {
  return (
    <section id="coverage" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Service Coverage</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Based in Eastern Canada, we can move your goods from cities like Montreal, Ottawa, and Toronto to most parts
            of North America with personalized, professional service.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 mb-12">
          <div className="text-center">
            <div className="mx-auto w-24 h-24 bg-red-100 rounded-full flex items-center justify-center mb-6">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 512 512"
                className="w-16 h-16"
                aria-label="Canadian Flag"
              >
                <path fill="#f0f0f0" d="M0 85.331h512v341.337H0z" />
                <path fill="#d80027" d="M0 85.331h170.663v341.337H0zM341.337 85.331H512v341.337H341.337z" />
                <path
                  fill="#d80027"
                  d="m288 279.704-32-16.001-32 16.001 11.798-36.267L204 212.001h39.651l12.349-38 12.349 38h39.651l-31.798 31.436z"
                />
              </svg>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Primary Service Areas</h3>
            <p className="text-gray-600 mb-6">Serving moves from key Eastern Canadian cities</p>
            <div className="flex flex-wrap justify-center gap-2">
              <Badge variant="secondary" className="text-sm py-1 px-3">
                Montreal
              </Badge>
              <Badge variant="secondary" className="text-sm py-1 px-3">
                Ottawa
              </Badge>
              <Badge variant="secondary" className="text-sm py-1 px-3">
                Toronto
              </Badge>
              <Badge variant="secondary" className="text-sm py-1 px-3">
                Surrounding Areas
              </Badge>
            </div>
          </div>

          <div className="text-center">
            <div className="mx-auto w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mb-6">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 512 512"
                className="w-16 h-16"
                aria-label="American Flag"
              >
                <path fill="#f0f0f0" d="M0 85.331h512v341.337H0z" />
                <g fill="#d80027">
                  <path d="M0 85.331h512v42.663H0zM0 170.657h512v42.663H0zM0 255.983h512v42.663H0zM0 341.309h512v42.663H0z" />
                </g>
                <path fill="#2e52b2" d="M0 85.331h256v183.797H0z" />
                <g fill="#f0f0f0">
                  <path d="m99.822 160.624-4.123 12.685h-13.334l10.793 7.842-4.123 12.683 10.787-7.839 10.786 7.839-4.122-12.683 10.792-7.842h-13.334zM103.938 219.081l-4.119-12.682-4.123 12.682H82.363l10.791 7.842-4.123 12.685 10.788-7.842 10.786 7.842-4.123-12.685 10.794-7.842zM47.577 219.081l-4.121-12.682-4.123 12.682H26l10.791 7.842-4.123 12.685 10.788-7.842 10.787 7.842-4.123-12.685 10.794-7.842zM43.46 160.624l-4.123 12.685H26l10.791 7.842-4.123 12.683 10.792-7.839 10.785 7.839-4.122-12.683 10.793-7.842H47.577zM99.822 114.878l-4.123 12.685h-13.334l10.793 7.842-4.123 12.683 10.787-7.839 10.786 7.839-4.122-12.683 10.792-7.842h-13.334zM43.46 114.878l-4.123 12.685H26l10.791 7.842-4.123 12.683 10.792-7.839 10.785 7.839-4.122-12.683 10.793-7.842H47.577zM156.183 160.624l-4.122 12.685h-13.333l10.792 7.842-4.122 12.683 10.786-7.839 10.785 7.839-4.12-12.683 10.791-7.842h-13.334zM160.3 219.081l-4.12-12.682-4.122 12.682h-13.333l10.792 7.842-4.123 12.685 10.786-7.842 10.785 7.842-4.12-12.685 10.791-7.842zM156.183 114.878l-4.122 12.685h-13.333l10.792 7.842-4.122 12.683 10.786-7.839 10.785 7.839-4.12-12.683 10.791-7.842h-13.334zM216.663 219.081l-4.122-12.682-4.123 12.682h-13.332l10.792 7.842-4.122 12.685 10.785-7.842 10.788 7.842-4.123-12.685 10.792-7.842zM212.546 160.624l-4.123 12.685h-13.334l10.793 7.842-4.123 12.683 10.787-7.839 10.787 7.839-4.123-12.683 10.794-7.842h-13.335zM212.546 114.878l-4.123 12.685h-13.334l10.793 7.842-4.123 12.683 10.787-7.839 10.787 7.839-4.123-12.683 10.794-7.842h-13.335z" />
                </g>
              </svg>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Destination Coverage</h3>
            <p className="text-gray-600 mb-6">Delivering to most parts of North America</p>
            <div className="flex flex-wrap justify-center gap-2">
              <Badge variant="secondary" className="text-sm py-1 px-3">
                Eastern USA
              </Badge>
              <Badge variant="secondary" className="text-sm py-1 px-3">
                Central USA
              </Badge>
              <Badge variant="secondary" className="text-sm py-1 px-3">
                Major Cities
              </Badge>
              <Badge variant="secondary" className="text-sm py-1 px-3">
                Cross-Border
              </Badge>
            </div>
          </div>
        </div>

        <div className="bg-orange-50 rounded-lg p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Why Choose Personal Service?</h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="mx-auto w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mb-4">
                <MapPin className="h-8 w-8 text-orange-600" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Personalized Service</h4>
              <p className="text-gray-600 text-sm">
                Direct communication with the owner - no middlemen or call centers
              </p>
            </div>
            <div className="text-center">
              <div className="mx-auto w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mb-4">
                <Truck className="h-8 w-8 text-orange-600" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Focused Expertise</h4>
              <p className="text-gray-600 text-sm">Specialized in Eastern Canada to North America routes</p>
            </div>
            <div className="text-center">
              <div className="mx-auto w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mb-4">
                <CheckCircle className="h-8 w-8 text-orange-600" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Quality Commitment</h4>
              <p className="text-gray-600 text-sm">Personal attention to every move - your success is my success</p>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <p className="text-lg text-gray-600 mb-4">
            <strong>Popular Routes:</strong> Montreal to New York, Ottawa to Boston, Toronto to Chicago, and other
            Eastern Canada to US destinations.
          </p>
          <p className="text-gray-600">
            Planning a move from Montreal, Ottawa, or Toronto?{" "}
            <a href="#contact" className="text-orange-600 font-semibold hover:underline">
              Contact me directly
            </a>{" "}
            to discuss your specific destination and get a personalized quote.
          </p>
        </div>
      </div>
    </section>
  )
}
