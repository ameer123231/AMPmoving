import { Card, CardContent } from "@/components/ui/card"
import { Star } from "lucide-react"

export function Testimonials() {
  const testimonials = [
    {
      name: "Sarah Johnson",
      location: "Toronto to Seattle",
      rating: 5,
      text: "Exceptional service! The team was professional, careful with our belongings, and made our cross-border move seamless. Ashton and his crew went above and beyond to ensure everything arrived safely. Highly recommended!",
      date: "2 weeks ago",
    },
    {
      name: "Mike Chen",
      location: "Vancouver to San Francisco",
      rating: 5,
      text: "AMP Moving handled our office relocation perfectly. Everything arrived on time and in perfect condition. Great communication throughout the entire process. The best moving company we've ever used!",
      date: "1 month ago",
    },
    {
      name: "Emily Rodriguez",
      location: "New York to Montreal",
      rating: 5,
      text: "Moving from the US to Canada seemed daunting, but AMP Moving made it easy. They handled all the paperwork and logistics flawlessly. Professional, reliable, and trustworthy. Worth every penny!",
      date: "3 weeks ago",
    },
    {
      name: "David Thompson",
      location: "Calgary to Denver",
      rating: 5,
      text: "Outstanding service from start to finish! The crew was punctual, careful, and incredibly efficient. They treated our furniture like it was their own. AMP Moving truly lives up to their 'Moving Lives' motto.",
      date: "1 week ago",
    },
    {
      name: "Lisa Martinez",
      location: "Ottawa to Boston",
      rating: 5,
      text: "I was nervous about my first international move, but AMP Moving made it stress-free. Excellent communication, fair pricing, and zero damage to any of my items. I'll definitely use them again!",
      date: "2 months ago",
    },
    {
      name: "Robert Kim",
      location: "Edmonton to Chicago",
      rating: 5,
      text: "Fantastic experience! The team was professional, friendly, and worked incredibly hard. They even helped me with last-minute packing. AMP Moving exceeded all my expectations. 5 stars all the way!",
      date: "3 weeks ago",
    },
    {
      name: "Jennifer Walsh",
      location: "Winnipeg to Minneapolis",
      rating: 5,
      text: "AMP Moving made our family's relocation smooth and easy. The crew was amazing with our kids and pets, and nothing was damaged. Great value for money and exceptional customer service!",
      date: "1 month ago",
    },
    {
      name: "Mark Stevens",
      location: "Halifax to Portland",
      rating: 5,
      text: "Professional, reliable, and efficient! AMP Moving handled our cross-country move with care and precision. Ashton's team is top-notch. I recommend them to anyone needing quality moving services.",
      date: "2 weeks ago",
    },
    {
      name: "Amanda Foster",
      location: "Quebec City to Burlington",
      rating: 5,
      text: "Incredible service! They were flexible with our timeline, careful with fragile items, and the pricing was very competitive. The whole team was courteous and professional. Couldn't ask for better!",
      date: "1 week ago",
    },
    {
      name: "James Wilson",
      location: "Regina to Kansas City",
      rating: 5,
      text: "AMP Moving delivered exactly what they promised. On-time pickup, safe transport, and careful delivery. The crew was hardworking and respectful. This is how moving should be done!",
      date: "3 weeks ago",
    },
    {
      name: "Michelle Brown",
      location: "London, ON to Detroit",
      rating: 5,
      text: "Exceptional cross-border moving experience! They handled all the customs paperwork and made the process seamless. Professional crew, fair pricing, and excellent communication throughout.",
      date: "1 month ago",
    },
    {
      name: "Kevin O'Connor",
      location: "St. John's to Miami",
      rating: 5,
      text: "Long-distance move from coast to coast and AMP Moving nailed it! Everything arrived in perfect condition. The team was professional, efficient, and genuinely cared about our belongings. Highly recommend!",
      date: "2 months ago",
    },
  ]

  return (
    <section id="testimonials" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">What Our Customers Say</h2>
          <p className="text-xl text-gray-600">
            Don't just take our word for it - hear from our satisfied customers across North America
          </p>
          <div className="flex items-center justify-center mt-6">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-6 w-6 text-yellow-400 fill-current" />
              ))}
            </div>
            <span className="ml-3 text-lg font-semibold text-gray-900">5.0 out of 5</span>
            <span className="ml-2 text-gray-600">({testimonials.length} reviews)</span>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow h-full">
              <CardContent className="p-6 flex flex-col h-full">
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4 italic flex-grow">"{testimonial.text}"</p>
                <div className="mt-auto">
                  <p className="font-semibold text-gray-900">{testimonial.name}</p>
                  <p className="text-sm text-gray-500">{testimonial.location}</p>
                  <p className="text-xs text-gray-400 mt-1">{testimonial.date}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-orange-50 rounded-lg p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Join Our Happy Customers</h3>
            <p className="text-lg text-gray-600 mb-6">
              Over 500+ successful moves across Canada and the USA. Experience the AMP Moving difference today!
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <p className="text-3xl font-bold text-orange-600">500+</p>
                <p className="text-sm text-gray-600">Happy Customers</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-orange-600">15+</p>
                <p className="text-sm text-gray-600">Years Experience</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-orange-600">99%</p>
                <p className="text-sm text-gray-600">On-Time Delivery</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-orange-600">0</p>
                <p className="text-sm text-gray-600">Damage Claims</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
