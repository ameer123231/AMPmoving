import { Facebook, Twitter, Instagram, Linkedin } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <h3 className="text-white font-bold text-xl">AMP Moving Inc</h3>
            </div>
            <p className="text-gray-400 mb-4">
              AMP Moving Inc - Professional moving services across Canada and the United States. Moving Lives with care
              and dedication.
            </p>
            <div className="flex space-x-4">
              <Facebook className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
              <Twitter className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
              <Instagram className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
              <Linkedin className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Services</h3>
            <ul className="space-y-2 text-gray-400">
              <li>
                <a href="#" className="hover:text-white">
                  Residential Moving
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Commercial Moving
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Packing Services
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Custom Crating & Installation
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Coverage</h3>
            <ul className="space-y-2 text-gray-400">
              <li>
                <a href="#" className="hover:text-white">
                  Canada
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  United States
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Cross-Border
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  International
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <ul className="space-y-2 text-gray-400">
              <li>Phone: (343) 204-6643</li>
              <li>Email: ashton@amp-moving.com</li>
              <li>Available 24/7 7 days a week</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 AMP Moving Inc. All rights reserved. Licensed and insured in Canada and USA.</p>
        </div>
      </div>
    </footer>
  )
}
