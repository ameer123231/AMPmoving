"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Star, Search, MapPin, ThumbsUp, Award, MessageSquare } from "lucide-react"

export function ReviewsPage() {
  const [filter, setFilter] = useState("all")
  const [sort, setSort] = useState("recent")
  const [searchQuery, setSearchQuery] = useState("")

  const allTestimonials = [
    {
      name: "Sarah Johnson",
      location: "Toronto to Seattle",
      rating: 5,
      text: "Exceptional service! The team was professional, careful with our belongings, and made our cross-border move seamless. Ashton and his crew went above and beyond to ensure everything arrived safely. They even helped us set up some of our furniture in our new home. The pricing was transparent with no hidden fees. Highly recommended!",
      date: "May 15, 2024",
      moveType: "residential",
      verified: true,
      highlight: "Careful handling of antiques",
    },
    {
      name: "Mike Chen",
      location: "Vancouver to San Francisco",
      rating: 5,
      text: "AMP Moving handled our office relocation perfectly. Everything arrived on time and in perfect condition. Great communication throughout the entire process. Ashton was always available to answer questions and provide updates. The crew was efficient and professional, making our business transition smooth with minimal downtime. The best moving company we've ever used!",
      date: "April 28, 2024",
      moveType: "commercial",
      verified: true,
      highlight: "Minimal business downtime",
    },
    {
      name: "Emily Rodriguez",
      location: "New York to Montreal",
      rating: 5,
      text: "Moving from the US to Canada seemed daunting, but AMP Moving made it easy. They handled all the paperwork and customs logistics flawlessly. The team was knowledgeable about cross-border regulations and made sure everything was properly documented. Professional, reliable, and trustworthy. Worth every penny for the peace of mind!",
      date: "May 3, 2024",
      moveType: "residential",
      verified: true,
      highlight: "Expert customs handling",
    },
    {
      name: "David Thompson",
      location: "Calgary to Denver",
      rating: 5,
      text: "Outstanding service from start to finish! The crew was punctual, careful, and incredibly efficient. They treated our furniture like it was their own. The packing service was excellent - not a single item was damaged. AMP Moving truly lives up to their 'Moving Lives' motto. I've already recommended them to several colleagues planning moves.",
      date: "April 10, 2024",
      moveType: "residential",
      verified: true,
      highlight: "Zero damage to belongings",
    },
    {
      name: "Lisa Martinez",
      location: "Ottawa to Boston",
      rating: 5,
      text: "I was nervous about my first international move, but AMP Moving made it stress-free. Excellent communication, fair pricing, and zero damage to any of my items. The team was friendly and professional, taking time to answer all my questions. They even helped me navigate the customs process with clear instructions. I'll definitely use them again!",
      date: "March 25, 2024",
      moveType: "residential",
      verified: true,
      highlight: "Stress-free experience",
    },
    {
      name: "Robert Kim",
      location: "Edmonton to Chicago",
      rating: 5,
      text: "Fantastic experience! The team was professional, friendly, and worked incredibly hard. They even helped me with last-minute packing when I fell behind schedule. The truck arrived exactly when promised, and the delivery was just as smooth. AMP Moving exceeded all my expectations. 5 stars all the way!",
      date: "May 8, 2024",
      moveType: "residential",
      verified: true,
      highlight: "Helped with last-minute packing",
    },
    {
      name: "Jennifer Walsh",
      location: "Winnipeg to Minneapolis",
      rating: 5,
      text: "AMP Moving made our family's relocation smooth and easy. The crew was amazing with our kids and pets, and nothing was damaged. They were patient and understanding with our special requests and schedule changes. Great value for money and exceptional customer service! The follow-up after the move was also impressive.",
      date: "April 5, 2024",
      moveType: "residential",
      verified: true,
      highlight: "Great with kids and pets",
    },
    {
      name: "Mark Stevens",
      location: "Halifax to Portland",
      rating: 5,
      text: "Professional, reliable, and efficient! AMP Moving handled our cross-country move with care and precision. Ashton's team is top-notch. The inventory system they used ensured nothing was lost or misplaced. The crew was respectful of our home and belongings. I recommend them to anyone needing quality moving services.",
      date: "March 15, 2024",
      moveType: "residential",
      verified: true,
      highlight: "Excellent inventory management",
    },
    {
      name: "Amanda Foster",
      location: "Quebec City to Burlington",
      rating: 5,
      text: "Incredible service! They were flexible with our timeline, careful with fragile items, and the pricing was very competitive. The whole team was courteous and professional. Their packing service was worth every penny - they used quality materials and packed everything securely. Couldn't ask for better!",
      date: "May 12, 2024",
      moveType: "residential",
      verified: true,
      highlight: "Superior packing service",
    },
    {
      name: "James Wilson",
      location: "Regina to Kansas City",
      rating: 5,
      text: "AMP Moving delivered exactly what they promised. On-time pickup, safe transport, and careful delivery. The crew was hardworking and respectful. They were particularly careful with our antique furniture pieces. This is how moving should be done! The online tracking system gave us peace of mind throughout the journey.",
      date: "April 20, 2024",
      moveType: "residential",
      verified: true,
      highlight: "Real-time shipment tracking",
    },
    {
      name: "Michelle Brown",
      location: "London, ON to Detroit",
      rating: 5,
      text: "Exceptional cross-border moving experience! They handled all the customs paperwork and made the process seamless. The team was knowledgeable about regulations and requirements for both countries. Professional crew, fair pricing, and excellent communication throughout. I appreciated the detailed inventory and condition reports.",
      date: "March 30, 2024",
      moveType: "residential",
      verified: true,
      highlight: "Detailed documentation",
    },
    {
      name: "Kevin O'Connor",
      location: "St. John's to Miami",
      rating: 5,
      text: "Long-distance move from coast to coast and AMP Moving nailed it! Everything arrived in perfect condition. The team was professional, efficient, and genuinely cared about our belongings. They accommodated our schedule changes without complaint. Highly recommend for any cross-country or international move!",
      date: "February 28, 2024",
      moveType: "residential",
      verified: true,
      highlight: "Coast-to-coast expertise",
    },
    {
      name: "Samantha Lee",
      location: "Toronto to Los Angeles",
      rating: 5,
      text: "AMP Moving handled our complicated move with multiple stops flawlessly. They coordinated everything perfectly and kept us informed throughout the process. The crew was professional and friendly. They took special care with our artwork and fragile items. Excellent service from start to finish!",
      date: "May 5, 2024",
      moveType: "residential",
      verified: true,
      highlight: "Complex multi-stop move",
    },
    {
      name: "Daniel Garcia",
      location: "Montreal to Chicago",
      rating: 5,
      text: "Best moving experience I've ever had! The team was punctual, efficient, and extremely careful with our belongings. They disassembled and reassembled our furniture perfectly. The price was exactly as quoted with no surprises. Ashton personally checked in to ensure everything was going smoothly. Highly recommend!",
      date: "April 15, 2024",
      moveType: "residential",
      verified: true,
      highlight: "Perfect furniture reassembly",
    },
    {
      name: "TechStart Inc.",
      location: "Vancouver to Silicon Valley",
      rating: 5,
      text: "AMP Moving handled our tech company's relocation with exceptional care. They understood the sensitivity of our equipment and took all necessary precautions. The specialized crating for our servers and workstations was impressive. The move was completed on schedule with zero issues. Highly recommend for business relocations!",
      date: "March 20, 2024",
      moveType: "commercial",
      verified: true,
      highlight: "Specialized tech equipment handling",
    },
    {
      name: "Global Design Group",
      location: "Toronto to New York",
      rating: 5,
      text: "Our design studio needed a mover who could handle delicate prototypes and expensive equipment. AMP Moving exceeded our expectations. Their custom crating solutions protected our most valuable items. The team was professional, efficient, and understood our unique needs. The move was completed on time and within budget.",
      date: "April 25, 2024",
      moveType: "commercial",
      verified: true,
      highlight: "Custom crating solutions",
    },
    {
      name: "Dr. William Parker",
      location: "Ottawa to Boston",
      rating: 5,
      text: "AMP Moving relocated my medical practice with exceptional care. They handled sensitive medical equipment and patient records with the utmost professionalism. The team worked after hours to minimize disruption to our patients. Everything was meticulously labeled and organized. Couldn't have asked for a better experience!",
      date: "March 10, 2024",
      moveType: "commercial",
      verified: true,
      highlight: "Medical office relocation",
    },
    {
      name: "Riverside Cafe",
      location: "Montreal to Burlington",
      rating: 5,
      text: "Moving our cafe equipment required specialized knowledge and care. AMP Moving delivered! They handled our expensive espresso machines, refrigeration units, and custom fixtures with expertise. The team worked efficiently to minimize our downtime. We were up and running in our new location ahead of schedule. Excellent service!",
      date: "May 1, 2024",
      moveType: "commercial",
      verified: true,
      highlight: "Restaurant equipment expertise",
    },
  ]

  // Filter testimonials based on selected filter and search query
  const filteredTestimonials = allTestimonials.filter((testimonial) => {
    const matchesFilter = filter === "all" || testimonial.moveType === filter
    const matchesSearch =
      searchQuery === "" ||
      testimonial.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      testimonial.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      testimonial.text.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesFilter && matchesSearch
  })

  // Sort testimonials based on selected sort option
  const sortedTestimonials = [...filteredTestimonials].sort((a, b) => {
    if (sort === "recent") {
      return new Date(b.date).getTime() - new Date(a.date).getTime()
    } else if (sort === "oldest") {
      return new Date(a.date).getTime() - new Date(b.date).getTime()
    }
    return 0
  })

  return (
    <div className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Customer Reviews</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Read what our customers have to say about their moving experience with AMP Moving Inc. We're proud of our
            track record of excellence across Canada and the United States.
          </p>
          <div className="flex items-center justify-center mt-6">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-6 w-6 text-yellow-400 fill-current" />
              ))}
            </div>
            <span className="ml-3 text-lg font-semibold text-gray-900">5.0 out of 5</span>
            <span className="ml-2 text-gray-600">({allTestimonials.length} reviews)</span>
          </div>
        </div>

        {/* Filter and Search */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <label htmlFor="filter" className="block text-sm font-medium text-gray-700 mb-1">
                Filter by Type
              </label>
              <Select value={filter} onValueChange={setFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter reviews" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Reviews</SelectItem>
                  <SelectItem value="residential">Residential Moves</SelectItem>
                  <SelectItem value="commercial">Commercial Moves</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label htmlFor="sort" className="block text-sm font-medium text-gray-700 mb-1">
                Sort by
              </label>
              <Select value={sort} onValueChange={setSort}>
                <SelectTrigger>
                  <SelectValue placeholder="Sort reviews" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recent">Most Recent</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-1">
                Search Reviews
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="search"
                  placeholder="Search by keyword, location..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Reviews Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="mx-auto w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-4">
                <ThumbsUp className="h-6 w-6 text-orange-600" />
              </div>
              <h3 className="text-3xl font-bold text-gray-900">100%</h3>
              <p className="text-sm text-gray-600">Satisfaction Rate</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="mx-auto w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-4">
                <Star className="h-6 w-6 text-orange-600" />
              </div>
              <h3 className="text-3xl font-bold text-gray-900">5.0</h3>
              <p className="text-sm text-gray-600">Average Rating</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="mx-auto w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-4">
                <Award className="h-6 w-6 text-orange-600" />
              </div>
              <h3 className="text-3xl font-bold text-gray-900">15+</h3>
              <p className="text-sm text-gray-600">Years of Service</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="mx-auto w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-4">
                <MessageSquare className="h-6 w-6 text-orange-600" />
              </div>
              <h3 className="text-3xl font-bold text-gray-900">{allTestimonials.length}</h3>
              <p className="text-sm text-gray-600">Verified Reviews</p>
            </CardContent>
          </Card>
        </div>

        {/* Reviews List */}
        <div className="grid md:grid-cols-2 gap-8">
          {sortedTestimonials.map((testimonial, index) => (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className="flex mb-1">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    <h3 className="font-semibold text-lg text-gray-900">{testimonial.name}</h3>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-500">{testimonial.date}</p>
                    {testimonial.verified && (
                      <span className="inline-flex items-center text-xs font-medium text-green-700 bg-green-50 px-2 py-0.5 rounded">
                        <svg
                          className="mr-1 h-3 w-3"
                          fill="currentColor"
                          viewBox="0 0 20 20"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            fillRule="evenodd"
                            d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                            clipRule="evenodd"
                          ></path>
                        </svg>
                        Verified Move
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center mb-4">
                  <MapPin className="h-4 w-4 text-orange-600 mr-1" />
                  <p className="text-sm text-gray-600">{testimonial.location}</p>
                </div>

                <p className="text-gray-700 mb-4">{testimonial.text}</p>

                {testimonial.highlight && (
                  <div className="bg-orange-50 px-4 py-2 rounded-md">
                    <p className="text-sm font-medium text-orange-800">
                      <span className="font-bold">Highlight:</span> {testimonial.highlight}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* No Results */}
        {sortedTestimonials.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-600">No reviews match your search criteria. Please try different filters.</p>
            <Button
              variant="outline"
              className="mt-4"
              onClick={() => {
                setFilter("all")
                setSearchQuery("")
              }}
            >
              Reset Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
