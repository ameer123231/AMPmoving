import { CheckCircle } from "lucide-react"

export function About() {
  const features = [
    "Licensed and insured in both Canada and USA",
    "15+ years of cross-border moving experience",
    "Professional, trained moving crews",
    "Modern fleet of well-maintained trucks",
    "Competitive pricing with no hidden fees",
    "Full-service packing and unpacking available",
  ]

  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Why Choose AMP Moving Inc?</h2>
            <p className="text-lg text-gray-600 mb-8">
              With over 15 years of experience in cross-border moving, we understand the unique challenges of relocating
              between Canada and the United States. Our team is dedicated to making your move as smooth and stress-free
              as possible.
            </p>

            <div className="space-y-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>

            <div className="mt-8 bg-orange-50 p-4 rounded-lg">
              <h3 className="font-semibold text-gray-900 mb-2">Family-Friendly Moving Experience</h3>
              <p className="text-gray-600">
                We understand that moving with children can be challenging. Our crews are experienced with family moves
                and go the extra mile to make the experience positive for everyone - even the little ones!
              </p>
            </div>
          </div>

          <div className="relative">
            <img
              src="/images/family-moving.jpg"
              alt="Happy children enjoying the moving experience with AMP Moving Inc"
              className="rounded-lg shadow-xl"
            />
            <div className="absolute -bottom-4 -left-4 bg-white p-3 rounded-lg shadow-lg">
              <p className="text-sm font-medium text-gray-900">"Making moving an adventure for the whole family!"</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
