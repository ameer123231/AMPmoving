"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Phone, MapPin, Clock, Truck } from "lucide-react"
import { QuoteModal } from "@/components/quote-modal"

export function Hero() {
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState(false)

  return (
    <section className="relative bg-gradient-to-r from-orange-50 to-red-50 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 leading-tight">
              Professional Moving Services
              <span className="text-orange-600"> Moving Lives</span> Across Canada & USA
            </h1>
            <p className="text-xl text-gray-600 mt-6 leading-relaxed">
              AMP Moving Inc - Your trusted cross-border moving company with over 15 years of experience. We specialize
              in long-range moves and handle residential and commercial relocations with care and professionalism, truly
              moving lives.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mt-8">
              <Button
                size="lg"
                className="bg-orange-600 hover:bg-orange-700 text-lg px-8"
                onClick={() => setIsQuoteModalOpen(true)}
              >
                Get Free Quote
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8">
                <Phone className="mr-2 h-5 w-5" />
                Call (343) 204-6643
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-12">
              <div className="flex items-center">
                <MapPin className="h-6 w-6 text-orange-600 mr-3" />
                <div>
                  <p className="font-semibold text-gray-900">Long-Range Moves</p>
                  <p className="text-sm text-gray-600">Any Distance</p>
                </div>
              </div>
              <div className="flex items-center">
                <Clock className="h-6 w-6 text-orange-600 mr-3" />
                <div>
                  <p className="font-semibold text-gray-900">24/7 Support</p>
                  <p className="text-sm text-gray-600">Always Available</p>
                </div>
              </div>
              <div className="flex items-center">
                <Truck className="h-6 w-6 text-orange-600 mr-3" />
                <div>
                  <p className="font-semibold text-gray-900">Insured</p>
                  <p className="text-sm text-gray-600">Fully Protected</p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
            <img
              src="/images/moving-truck.png"
              alt="AMP Moving truck on a scenic route"
              className="rounded-lg shadow-2xl w-full h-auto"
            />
          </div>
        </div>
      </div>
      <QuoteModal isOpen={isQuoteModalOpen} onClose={() => setIsQuoteModalOpen(false)} />
    </section>
  )
}
